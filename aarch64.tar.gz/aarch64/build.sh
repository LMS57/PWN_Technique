#!/bin/sh

rm ./rootfs2.cpio.gz
cd tmp
sudo find . | sudo cpio --create --format='newc' > ../rootfs2.cpio
cd .. 
gzip ./rootfs2.cpio
