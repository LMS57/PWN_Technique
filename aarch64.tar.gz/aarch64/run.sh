#!/bin/sh

cd `dirname "$0"`
qemu-system-aarch64 \
    -nographic \
    -smp 2 \
    -machine virt,secure=on -cpu cortex-a57 \
    -d unimp -semihosting-config enable,target=native \
    -m 2048M \
    -bios bl1.bin \
    -initrd rootfs.cpio.gz \
    -kernel Image -no-acpi \
    -monitor null -serial stdio \
    -append "root=/dev/ram console=ttyAMA0"



#-netdev bridge,id=br1 -device virtio-net,netdev=br1 \
