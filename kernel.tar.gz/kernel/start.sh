#/bin/bash
cd challenge/
timeout 30 ./run.sh
