Challenge is taken from https://github.com/esanfelix/r2con2019-ctf-kernel
